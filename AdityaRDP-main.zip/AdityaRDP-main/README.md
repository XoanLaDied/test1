# Free RDP 6JAM

<img src="https://github.com/AdityaGans2542/AdityaRDP/blob/main/wallpaper.png" width=900 height="600" align="center">
<center>
<p align="center">
<a href="#"><img title="Whatsapp-Bot" src="https://img.shields.io/badge/AdityaRDP-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://www.codefactor.io/repository/github/adityagans2542/adityardp/badge"><img title="Rating" src="https://www.codefactor.io/repository/github/adityagans2542/adityardp/badge"></a>
<p align="center">
<a href="https://github.com/AdityaGans2642"><img title="Author" src="https://img.shields.io/badge/AUTHOR-ADITYA-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/AdityaGans2542/followers"><img title="Followers" src="https://img.shields.io/github/followers/AdityaGans2542?color=blue&style=flat-square"></a>
<a href="https://github.com/AdityaGans2542/AdityaRDP/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/AdityaGans2542/AdityaRDP?color=red&style=flat-square"></a>
<a href="https://github.com/AdityaGans2542/AdityaRDP/network/members"><img title="Forks" src="https://img.shields.io/github/forks/AdityaGans2542/AdityaRDP?color=red&style=flat-square"></a>
<a href="https://github.com/AdityaGans2542/AdityaRDP/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/AdityaGans2542/AdityaRDP?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FAdityaGans2542%2FAdityaRDP&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>

<details>
 <summary>😍 Help me!</summary>
 
 [TRAKTEER](https://trakteer.id/aditya2542)
 
</details>
ini semua gratis, jangan pelit ⭐️ ya :D

### CARA CREATE AdityaRDP
```
> Tekan Tombol Fork untuk membuat RDP (Bagi Pengguna Android/HP Disilahkan Pake Mode Desktop).

> kunjungi https://dashboard.ngrok.com untuk mendapatkan NGROK_AUTH_TOKEN

> Di Dalam Repo ini Pergi ke Settings> Secrets> New repository secret

> isi Nama: Masukan NGROK_AUTH_TOKEN

> isi Value: Kunjungi https://dashboard.ngrok.com/auth/your-authtoken Copy Dan Paste di dalam value

> Tekan Add secret 

> Pergi Ke Action> CI> Run workflow

> Refresh Web dan masuk ke CI> build

> Tekan Tombol panah menghadap ke bawah "RDP INFO LOGIN" Untuk Mendapatkan IP, User, Password.
```

